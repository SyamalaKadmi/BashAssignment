#!/bin/bash

userName=$(whoami) #Username
userId=$(id -u) #User ID
groupId=$(id -g) #Group Id
homeDir=$HOME #Home Directory
shellUsed=$(echo $SHELL) # Shell being used

# Displaying user information
echo "Username: $userName"
echo "User ID: $userId"
echo "Group ID: $groupId"
echo "Home Directory: $homeDir"
echo "Shell: $shellUsed"
