#!/bin/bash

# To check if the directory is provided
if [ "$#" -ne 1 ]; then
        echo "Please provide directory path for backup"
        exit 1
fi

# Assign the directory argument to a variable
dir="$1"

# To check if the directory is valid
if [ ! -d "$dir" ]; then
        echo "Error: $dir is not a valid directory."
        exit 1
fi

# Create a new backup directory with a timestamp
timeStamp=$(date +"%Y%m%d_%H%M%S")
backupDir="$dir/backup_$timeStamp"

mkdir "$backupDir"

# Find and copy all .txt files to the backup directory
find "$dir" -type f -name "*.txt" -exec cp {} "$backupDir" \;

echo "Backup completed. All .txt files have been copied to $backupDir."