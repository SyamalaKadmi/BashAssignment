#!/bin/bash

#Set the threshold for disk usage
threshold=80
# Set the email address for alerts
email="sysadmin@abc.com"

# Get the current disk usage percentage for the root filesystem
usage=$(df / | grep / | awk '{ print $5 }' | sed 's/%//g')
# df - checks disk usage
# grep - to filter the output
# awk - to extract
# sed - to remove % sign from output

# Check if the usage exceeds the threshold
if [ "$usage" -gt "$threshold" ]; then
        # Send an email alert
        subject="Disk Usage Alert: ${usage}%"
        message="Warning: The root filesystem usage is at ${usage}%. Please take action to free up space."                      
		echo "$message" | mail -s "$subject" "$email"
		# To use mail keyword, please make sure to run the command -> sudo apt-get install mailutils"
        echo "Alert email sent to $email."
else
        echo "Disk usage is under control: ${usage}%."
fi