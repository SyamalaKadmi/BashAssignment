#!/bin/bash

report="system_report.txt"

# Create or clear the report file
> "$report"

echo "System Information Report" >> "$report"
echo "=========================" >> "$report"
echo "" >> "$report"

# System uptime
echo "System Uptime:" >> "$report"
uptime >> "$report"
echo "" >> "$report"

# Memory usage
echo "Memory Usage:" >> "$report"
free -h >> "$report"
echo "" >> "$report"

# CPU load
echo "CPU Load:" >> "$report"
top -bn1 | grep "Cpu(s)" >> "$report"
echo "" >> "$report"

# Disk usage
echo "Disk Usage:" >> "$report"
df -h >> "$report"
echo "" >> "$report"

# Running processes
echo "Running Processes:" >> "$report"
ps aux --sort=-%mem >> "$report"  
echo "" >> "$report"


echo "System Information report saved to $report"
