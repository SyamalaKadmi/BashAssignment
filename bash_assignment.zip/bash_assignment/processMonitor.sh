#!/bin/bash

# Check if the process name is provided
if [ "$#" -ne 1 ]; then
		echo "Please provide the process name"
        exit 1
fi

# Assign the process name argument to a variable
processName="$1"

logFile="/var/log/process_monitor.log"

# Check if the process is running
if ! pgrep -x "$processName" > /dev/null; then
    # Start the process
    systemctl start "$processName"

    # Log the action
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $processName was not running and has been started." >> "$logFile"
else
    echo "$processName is running."
fi
