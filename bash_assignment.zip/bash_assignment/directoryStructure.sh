#!/bin/bash
if [ ! -d home/user ]; then
        mkdir -p home/user;
        echo home/user directory structure created
        # To check and create home/user directory structure
fi
if [ ! -d home/projects/project1 ]; then
        mkdir -p home/projects/project1;
        echo home/projects/project1 directory structure created
        # To check and create home/projects/project1 directory structure
fi
if [ ! -d home/projects/project2 ]; then
        mkdir -p home/projects/project2;
        echo home/projects/project2 directory structure created
        # To check and create home/projects/project2 directory structure
fi
if [ ! -d home/projects/project3 ]; then
        mkdir -p home/projects/project3;
        echo home/projects/project3 directory structure created
        # To check and create home/projects/project3 directory structure
fi
if [ ! -d home/documents ]; then
        mkdir -p home/documents;
        echo home/documents directory structure created
        # To check and create home/documents directory structure
fi
if [ ! -d home/downloads ]; then
        mkdir -p home/downloads;
        echo home/downloads directory structure created
        # To check and create home/downloads directory structure
fi