#!/bin/bash

#Check if a filename is provided
if [ "$#" -ne 1 ]; then
        echo "Please provide the text filename"
        exit 1
fi

# Assign the filename to a variable
file="$1"

# Check if the file exists
if [ ! -f "$file" ]; then
        echo "Error: $file does not exist or is not a valid file."
        exit 1
fi

if [[ "$file" != *.txt ]]; then
            echo "Error: Input should be a text file."
            exit 1
fi

# To count lines, words, and characters
numberOfLines=$(wc -l < "$file")
numberOfWords=$(wc -w < "$file")
numberOfCharacters=$(wc -c < "$file")

# Display the counts
echo "Number of Lines: $numberOfLines"
echo "Number of Words: $numberOfWords"
echo "Number of Characters: $numberOfCharacters"