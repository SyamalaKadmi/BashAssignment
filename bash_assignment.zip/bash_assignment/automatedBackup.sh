#!/bin/bash

source="home/user/documents"
backup="home/user/backup"
backupFile="documents_backup.tar.gz"

# To check if the source directory exists
if [ ! -d $source ]; then
          echo "$source does not exist."
          exit 1
fi

# Create the backup directory if it doesn't exist
mkdir -p "$backup"

# Compress the documents directory into a tarball\
tar -czf "$backup/$backupFile" -C "$source" .

echo "Backup of '$source' created at '$backup/$backupFile'."

echo " To schedule the script to run dailys using cron, type crontab -e to open crontab editor"
echo " enter --> 0 <timeofthedaytorun> * * * /path/to/script , save and close the editor"