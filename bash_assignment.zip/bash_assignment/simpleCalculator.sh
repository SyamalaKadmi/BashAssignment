#!/bin/bash

# Function to perform arithmetic operations
calculator() {
    case $3 in
        +)
            echo "Sum of $1 and $2 : $(($1 + $2))"
            ;;
        -)
            echo "Subtraction of $1 and $2 : $(($1 - $2))"
            ;;
        \*)
            echo "Multiplication of $1 and $2 : $(($1 * $2))"
            ;;
        /)
            if [ "$2" -eq 0 ]; then
                echo "Error: Division by zero is not allowed."
            else
                echo "Division of $1 and $2 : $(($1 / $2))"
            fi
            ;;
        *)
            echo "Error: Invalid operator. Please use +, -, *, or /."
            ;;
    esac
}

# Prompt the user for input
read -p "Enter the first number: " num1
read -p "Enter the second number: " num2
read -p "Enter the operator (+, -, *, /): " operator

# Perform the calculation
calculator "$num1" "$num2" "$operator"
