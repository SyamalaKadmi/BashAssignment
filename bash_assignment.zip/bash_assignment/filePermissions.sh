#!/bin/bash

# Check if the file name is provided
if [ "$#" -ne 1 ]; then
		echo "Please provide the file name"
        exit 1
fi

# Assign the file argument to a variable
fileName="$1"

# Check if the file exists
if [ ! -e "$fileName" ]; then
        echo "Error: $fileName does not exist."
        exit 1
fi

# Check for read permission
if [ -r "$fileName" ]; then
        echo "Read permission: Granted"
else
        echo "Read permission: Denied"
fi

# Check for write permission
if [ -w "$fileName" ]; then
        echo "Write permission: Granted"
else
        echo "Write permission: Denied"
fi

# Check for execute permission
if [ -x "$fileName" ]; then
        echo "Execute permission: Granted"
else
        echo "Execute permission: Denied"
fi